const symbols=["🍒","🍋","⭐","💎","🔔","7️⃣"];let points=1000,busy=false;
const modal=document.getElementById("modal"),p=document.getElementById("points"),out=document.getElementById("result");
function openGame(){modal.classList.add("show")}function closeGame(){modal.classList.remove("show")}
function spin(){if(busy||points<10)return;busy=true;points-=10;p.textContent=points;out.textContent="Memutar...";
let n=0,t=setInterval(()=>{["a","b","c"].forEach(id=>document.getElementById(id).textContent=symbols[Math.floor(Math.random()*symbols.length)]);if(++n>=12){clearInterval(t);let x=["a","b","c"].map(id=>document.getElementById(id).textContent),win=x[0]===x[1]&&x[1]===x[2]?100:(x[0]===x[1]||x[1]===x[2]||x[0]===x[2]?20:0);points+=win;p.textContent=points;out.textContent=win?`🎉 +${win} poin virtual!`:"Belum menang. Coba lagi!";busy=false}},80)}
